classdef GaussianParameters
  properties
    RayleighDistance
    InitialWaist
    PropagationDistance
    Wavelength
  end
  
  properties (Dependent)
    k
    Waist
    Radius
    PhiPhase
    Amplitude
  end

  methods
    function Parameters = GaussianParameters
        k            = 2*RayleighDistance/InitialWaist;
        Waist        = waistPhysicalGaussianBeam(PropagationDistance,InitialWaist,RayleighDistance);
        Radius       = radiusPhysicalGaussianBeam(PropagationDistance,RayleighDistance);
        Phase        = phasePhysicalGaussianBeam(PropagationDistance,RayleighDistance);
      
      
   
    end
  end
end